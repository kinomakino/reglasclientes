# 🛡️ Azure Sentinel TTP Analyzer - VERSIÓN OFFLINE

## ⚡ Inicio Súper Rápido (3 pasos)

### 1️⃣ Obtener tus Event IDs desde Sentinel

Ve a **Azure Portal → Sentinel → Logs** y ejecuta:

```kql
SecurityEvent
| where TimeGenerated > ago(7d)
| distinct EventID
| order by EventID asc
```

### 2️⃣ Copiar resultados a archivo

Copia los Event IDs y pégalos en un archivo llamado `event_ids.txt` en esta carpeta.

**Ejemplo** (`event_ids.txt`):
```
4624
4625
4634
4648
4672
4688
```

### 3️⃣ Ejecutar

```bash
python analyzer_offline.py
```

**¡Eso es TODO!** 🎉

---

## 📋 Formatos Aceptados

El script acepta múltiples formatos de `event_ids.txt`:

### Formato 1: Un Event ID por línea (recomendado)
```
4624
4625
4688
```

### Formato 2: CSV
```
4624,4625,4688,4720
```

### Formato 3: Salida KQL copiada directamente
```
EventID
-------
4624
4625
4688
```

**El script detecta automáticamente el formato** y extrae los números.

---

## 📊 Salidas

Genera:
- ✅ **Dashboard HTML interactivo** en `output/sentinel_mitre_dashboard.html`
- ✅ **Estadísticas de cobertura** en consola
- ✅ **Top 10 recomendaciones** de Event IDs a activar

---

## 💡 Ventajas de la Versión Offline

✅ **Sin autenticación** - No necesitas tokens ni permisos  
✅ **Sin Azure CLI** - Solo Python  
✅ **Funciona siempre** - No depende de APIs  
✅ **Más rápido** - Sin network calls  
✅ **Portable** - Comparte el archivo `event_ids.txt`  

---

## 🔍 Ejemplo Completo

```bash
# 1. Crear archivo con tus Event IDs
echo "4624
4625
4688
4720
4698" > event_ids.txt

# 2. Ejecutar
python analyzer_offline.py

# 3. Abrir dashboard
# Se genera en: output/sentinel_mitre_dashboard.html
```

---

## ❓ FAQ

### ¿Qué query usar en Sentinel?

**Para los últimos 7 días:**
```kql
SecurityEvent
| where TimeGenerated > ago(7d)
| distinct EventID
| order by EventID asc
```

**Para los últimos 30 días:**
```kql
SecurityEvent
| where TimeGenerated > ago(30d)
| distinct EventID
| order by EventID asc
```

### ¿Puedo usar datos de producción?

Sí, solo necesitas los Event IDs (números), no hay datos sensibles.

### ¿Qué hago si no tengo acceso a Sentinel?

Pide a alguien con acceso que ejecute la query y te pase los resultados.

### ¿Funciona con otras tablas?

Sí, si tus eventos están en `Event` o `WindowsEvent`, usa:

```kql
Event
| where TimeGenerated > ago(7d)
| distinct EventID
| order by EventID asc
```

---

## 🎯 Lo Que Obtienes

### En Consola:
```
📊 ESTADÍSTICAS:
   Total técnicas mapeadas: 31
   ✅ Detectables (100%):    15
   ⚠️  Parciales:             10
   ❌ No detectables (0%):   6
   📈 Cobertura general:     48.4%

💡 TOP 10 Event IDs RECOMENDADOS:
 1. 🔴 Event ID 4663 → 4 críticas, 6 total
 2. 🔴 Event ID 4656 → 3 críticas, 4 total
```

### En Dashboard HTML:
- 📊 Gráfico circular de cobertura
- 🎯 Lista completa de técnicas MITRE
- 🔍 Búsqueda y filtros interactivos
- 💡 Recomendaciones priorizadas
- ✅ Event IDs disponibles

---

## 🚀 Próximos Pasos

1. Ejecuta el análisis
2. Revisa el dashboard HTML
3. Implementa los Event IDs recomendados
4. Vuelve a ejecutar para ver la mejora

**¡Eso es todo!** Súper simple. 😎
