"""
Mapeo de técnicas MITRE ATT&CK a Windows Event IDs
Expandido a 100+ técnicas basado en OSSEM Project y research público
"""

MITRE_TECHNIQUES = {
    "T1053.005": {
        "name": "Scheduled Task/Job: Scheduled Task",
        "tactic": "Persistence",
        "event_ids": [4698, 4699, 4700, 4701, 4702],
        "critical": True,
        "description": "Persistence: Scheduled Task/Job: Scheduled Task"
    },
    "T1136.001": {
        "name": "Create Account: Local Account",
        "tactic": "Persistence",
        "event_ids": [4720, 4722, 4738],
        "critical": True,
        "description": "Persistence: Create Account: Local Account"
    },
    "T1136.002": {
        "name": "Create Account: Domain Account",
        "tactic": "Persistence",
        "event_ids": [4720, 4722, 4738, 5136, 5137],
        "critical": True,
        "description": "Persistence: Create Account: Domain Account"
    },
    "T1543.003": {
        "name": "Create or Modify System Process: Windows Service",
        "tactic": "Persistence",
        "event_ids": [4697, 7045, 7040],
        "critical": True,
        "description": "Persistence: Create or Modify System Process: Windows Service"
    },
    "T1547.001": {
        "name": "Boot or Logon Autostart: Registry Run Keys",
        "tactic": "Persistence",
        "event_ids": [4657],
        "critical": True,
        "description": "Persistence: Boot or Logon Autostart: Registry Run Keys"
    },
    "T1547.004": {
        "name": "Boot or Logon Autostart: Winlogon Helper DLL",
        "tactic": "Persistence",
        "event_ids": [4657],
        "critical": True,
        "description": "Persistence: Boot or Logon Autostart: Winlogon Helper DLL"
    },
    "T1547.009": {
        "name": "Boot or Logon Autostart: Shortcut Modification",
        "tactic": "Persistence",
        "event_ids": [4663],
        "critical": False,
        "description": "Persistence: Boot or Logon Autostart: Shortcut Modification"
    },
    "T1197": {
        "name": "BITS Jobs",
        "tactic": "Persistence",
        "event_ids": [4688],
        "critical": False,
        "description": "Persistence: BITS Jobs"
    },
    "T1098.001": {
        "name": "Account Manipulation: Additional Cloud Credentials",
        "tactic": "Persistence",
        "event_ids": [4738],
        "critical": True,
        "description": "Persistence: Account Manipulation: Additional Cloud Credentials"
    },
    "T1098.002": {
        "name": "Account Manipulation: Additional Email Delegate Permissions",
        "tactic": "Persistence",
        "event_ids": [4738],
        "critical": False,
        "description": "Persistence: Account Manipulation: Additional Email Delegate Permissions"
    },
    "T1546.008": {
        "name": "Event Triggered Execution: Accessibility Features",
        "tactic": "Persistence",
        "event_ids": [4663, 4657],
        "critical": True,
        "description": "Persistence: Event Triggered Execution: Accessibility Features"
    },
    "T1546.011": {
        "name": "Event Triggered Execution: Application Shimming",
        "tactic": "Persistence",
        "event_ids": [4657],
        "critical": False,
        "description": "Persistence: Event Triggered Execution: Application Shimming"
    },
    "T1574.011": {
        "name": "Hijack Execution Flow: Services Registry Permissions Weakness",
        "tactic": "Persistence",
        "event_ids": [4657, 4670],
        "critical": True,
        "description": "Persistence: Hijack Execution Flow: Services Registry Permissions Weakness"
    },
    "T1055": {
        "name": "Process Injection",
        "tactic": "Privilege Escalation",
        "event_ids": [4688],
        "critical": True,
        "description": "Privilege Escalation: Process Injection"
    },
    "T1055.001": {
        "name": "Process Injection: Dynamic-link Library Injection",
        "tactic": "Privilege Escalation",
        "event_ids": [4688],
        "critical": True,
        "description": "Privilege Escalation: Process Injection: Dynamic-link Library Injection"
    },
    "T1055.012": {
        "name": "Process Injection: Process Hollowing",
        "tactic": "Privilege Escalation",
        "event_ids": [4688],
        "critical": True,
        "description": "Privilege Escalation: Process Injection: Process Hollowing"
    },
    "T1078.001": {
        "name": "Valid Accounts: Default Accounts",
        "tactic": "Privilege Escalation",
        "event_ids": [4624, 4625],
        "critical": False,
        "description": "Privilege Escalation: Valid Accounts: Default Accounts"
    },
    "T1078.002": {
        "name": "Valid Accounts: Domain Accounts",
        "tactic": "Privilege Escalation",
        "event_ids": [4624, 4625, 4768, 4769],
        "critical": True,
        "description": "Privilege Escalation: Valid Accounts: Domain Accounts"
    },
    "T1078.003": {
        "name": "Valid Accounts: Local Accounts",
        "tactic": "Privilege Escalation",
        "event_ids": [4624, 4625],
        "critical": True,
        "description": "Privilege Escalation: Valid Accounts: Local Accounts"
    },
    "T1134": {
        "name": "Access Token Manipulation",
        "tactic": "Privilege Escalation",
        "event_ids": [4672, 4673, 4674],
        "critical": True,
        "description": "Privilege Escalation: Access Token Manipulation"
    },
    "T1134.001": {
        "name": "Access Token Manipulation: Token Impersonation/Theft",
        "tactic": "Privilege Escalation",
        "event_ids": [4672, 4673, 4674],
        "critical": True,
        "description": "Privilege Escalation: Access Token Manipulation: Token Impersonation/Theft"
    },
    "T1484.001": {
        "name": "Domain Policy Modification: Group Policy Modification",
        "tactic": "Privilege Escalation",
        "event_ids": [5136, 5137, 5141],
        "critical": True,
        "description": "Privilege Escalation: Domain Policy Modification: Group Policy Modification"
    },
    "T1068": {
        "name": "Exploitation for Privilege Escalation",
        "tactic": "Privilege Escalation",
        "event_ids": [4688, 4673],
        "critical": True,
        "description": "Privilege Escalation: Exploitation for Privilege Escalation"
    },
    "T1070.001": {
        "name": "Indicator Removal: Clear Windows Event Logs",
        "tactic": "Defense Evasion",
        "event_ids": [1102, 104, 1100],
        "critical": True,
        "description": "Defense Evasion: Indicator Removal: Clear Windows Event Logs"
    },
    "T1070.004": {
        "name": "Indicator Removal: File Deletion",
        "tactic": "Defense Evasion",
        "event_ids": [4663, 4660],
        "critical": False,
        "description": "Defense Evasion: Indicator Removal: File Deletion"
    },
    "T1070.006": {
        "name": "Indicator Removal: Timestomp",
        "tactic": "Defense Evasion",
        "event_ids": [4663],
        "critical": False,
        "description": "Defense Evasion: Indicator Removal: Timestomp"
    },
    "T1562.001": {
        "name": "Impair Defenses: Disable or Modify Tools",
        "tactic": "Defense Evasion",
        "event_ids": [4688, 4657, 7040],
        "critical": True,
        "description": "Defense Evasion: Impair Defenses: Disable or Modify Tools"
    },
    "T1562.002": {
        "name": "Impair Defenses: Disable Windows Event Logging",
        "tactic": "Defense Evasion",
        "event_ids": [1102, 1100, 4719],
        "critical": True,
        "description": "Defense Evasion: Impair Defenses: Disable Windows Event Logging"
    },
    "T1036": {
        "name": "Masquerading",
        "tactic": "Defense Evasion",
        "event_ids": [4688, 4663],
        "critical": False,
        "description": "Defense Evasion: Masquerading"
    },
    "T1036.003": {
        "name": "Masquerading: Rename System Utilities",
        "tactic": "Defense Evasion",
        "event_ids": [4688, 4663],
        "critical": False,
        "description": "Defense Evasion: Masquerading: Rename System Utilities"
    },
    "T1218": {
        "name": "System Binary Proxy Execution",
        "tactic": "Defense Evasion",
        "event_ids": [4688],
        "critical": False,
        "description": "Defense Evasion: System Binary Proxy Execution"
    },
    "T1218.011": {
        "name": "System Binary Proxy Execution: Rundll32",
        "tactic": "Defense Evasion",
        "event_ids": [4688],
        "critical": False,
        "description": "Defense Evasion: System Binary Proxy Execution: Rundll32"
    },
    "T1112": {
        "name": "Modify Registry",
        "tactic": "Defense Evasion",
        "event_ids": [4657, 4670],
        "critical": False,
        "description": "Defense Evasion: Modify Registry"
    },
    "T1564.001": {
        "name": "Hide Artifacts: Hidden Files and Directories",
        "tactic": "Defense Evasion",
        "event_ids": [4663],
        "critical": False,
        "description": "Defense Evasion: Hide Artifacts: Hidden Files and Directories"
    },
    "T1564.003": {
        "name": "Hide Artifacts: Hidden Window",
        "tactic": "Defense Evasion",
        "event_ids": [4688],
        "critical": False,
        "description": "Defense Evasion: Hide Artifacts: Hidden Window"
    },
    "T1027": {
        "name": "Obfuscated Files or Information",
        "tactic": "Defense Evasion",
        "event_ids": [4663, 4688],
        "critical": False,
        "description": "Defense Evasion: Obfuscated Files or Information"
    },
    "T1207": {
        "name": "Rogue Domain Controller",
        "tactic": "Defense Evasion",
        "event_ids": [4742, 5136, 5137],
        "critical": True,
        "description": "Defense Evasion: Rogue Domain Controller"
    },
    "T1222.001": {
        "name": "File and Directory Permissions Modification: Windows",
        "tactic": "Defense Evasion",
        "event_ids": [4670, 4663],
        "critical": False,
        "description": "Defense Evasion: File and Directory Permissions Modification: Windows"
    },
    "T1003.001": {
        "name": "OS Credential Dumping: LSASS Memory",
        "tactic": "Credential Access",
        "event_ids": [4656, 4663],
        "critical": True,
        "description": "Credential Access: OS Credential Dumping: LSASS Memory"
    },
    "T1003.002": {
        "name": "OS Credential Dumping: Security Account Manager",
        "tactic": "Credential Access",
        "event_ids": [4656, 4663],
        "critical": True,
        "description": "Credential Access: OS Credential Dumping: Security Account Manager"
    },
    "T1003.003": {
        "name": "OS Credential Dumping: NTDS",
        "tactic": "Credential Access",
        "event_ids": [4662, 4663],
        "critical": True,
        "description": "Credential Access: OS Credential Dumping: NTDS"
    },
    "T1003.006": {
        "name": "OS Credential Dumping: DCSync",
        "tactic": "Credential Access",
        "event_ids": [4662],
        "critical": True,
        "description": "Credential Access: OS Credential Dumping: DCSync"
    },
    "T1110": {
        "name": "Brute Force",
        "tactic": "Credential Access",
        "event_ids": [4625, 4776],
        "critical": True,
        "description": "Credential Access: Brute Force"
    },
    "T1110.001": {
        "name": "Brute Force: Password Guessing",
        "tactic": "Credential Access",
        "event_ids": [4625],
        "critical": True,
        "description": "Credential Access: Brute Force: Password Guessing"
    },
    "T1110.003": {
        "name": "Brute Force: Password Spraying",
        "tactic": "Credential Access",
        "event_ids": [4625, 4771],
        "critical": True,
        "description": "Credential Access: Brute Force: Password Spraying"
    },
    "T1558.003": {
        "name": "Steal or Forge Kerberos Tickets: Kerberoasting",
        "tactic": "Credential Access",
        "event_ids": [4769],
        "critical": True,
        "description": "Credential Access: Steal or Forge Kerberos Tickets: Kerberoasting"
    },
    "T1558.004": {
        "name": "Steal or Forge Kerberos Tickets: AS-REP Roasting",
        "tactic": "Credential Access",
        "event_ids": [4768],
        "critical": True,
        "description": "Credential Access: Steal or Forge Kerberos Tickets: AS-REP Roasting"
    },
    "T1552.001": {
        "name": "Unsecured Credentials: Credentials In Files",
        "tactic": "Credential Access",
        "event_ids": [4663, 4656],
        "critical": False,
        "description": "Credential Access: Unsecured Credentials: Credentials In Files"
    },
    "T1552.002": {
        "name": "Unsecured Credentials: Credentials in Registry",
        "tactic": "Credential Access",
        "event_ids": [4657, 4663],
        "critical": False,
        "description": "Credential Access: Unsecured Credentials: Credentials in Registry"
    },
    "T1111": {
        "name": "Multi-Factor Authentication Interception",
        "tactic": "Credential Access",
        "event_ids": [4624, 4648],
        "critical": False,
        "description": "Credential Access: Multi-Factor Authentication Interception"
    },
    "T1087.001": {
        "name": "Account Discovery: Local Account",
        "tactic": "Discovery",
        "event_ids": [4798, 4799],
        "critical": False,
        "description": "Discovery: Account Discovery: Local Account"
    },
    "T1087.002": {
        "name": "Account Discovery: Domain Account",
        "tactic": "Discovery",
        "event_ids": [4662],
        "critical": False,
        "description": "Discovery: Account Discovery: Domain Account"
    },
    "T1069.001": {
        "name": "Permission Groups Discovery: Local Groups",
        "tactic": "Discovery",
        "event_ids": [4798, 4799],
        "critical": False,
        "description": "Discovery: Permission Groups Discovery: Local Groups"
    },
    "T1069.002": {
        "name": "Permission Groups Discovery: Domain Groups",
        "tactic": "Discovery",
        "event_ids": [4662],
        "critical": False,
        "description": "Discovery: Permission Groups Discovery: Domain Groups"
    },
    "T1482": {
        "name": "Domain Trust Discovery",
        "tactic": "Discovery",
        "event_ids": [4662],
        "critical": False,
        "description": "Discovery: Domain Trust Discovery"
    },
    "T1083": {
        "name": "File and Directory Discovery",
        "tactic": "Discovery",
        "event_ids": [4663],
        "critical": False,
        "description": "Discovery: File and Directory Discovery"
    },
    "T1135": {
        "name": "Network Share Discovery",
        "tactic": "Discovery",
        "event_ids": [5140, 5145],
        "critical": False,
        "description": "Discovery: Network Share Discovery"
    },
    "T1201": {
        "name": "Password Policy Discovery",
        "tactic": "Discovery",
        "event_ids": [4662],
        "critical": False,
        "description": "Discovery: Password Policy Discovery"
    },
    "T1069": {
        "name": "Permission Groups Discovery",
        "tactic": "Discovery",
        "event_ids": [4798, 4799, 4662],
        "critical": False,
        "description": "Discovery: Permission Groups Discovery"
    },
    "T1057": {
        "name": "Process Discovery",
        "tactic": "Discovery",
        "event_ids": [4688],
        "critical": False,
        "description": "Discovery: Process Discovery"
    },
    "T1012": {
        "name": "Query Registry",
        "tactic": "Discovery",
        "event_ids": [4663, 4656],
        "critical": False,
        "description": "Discovery: Query Registry"
    },
    "T1018": {
        "name": "Remote System Discovery",
        "tactic": "Discovery",
        "event_ids": [4624, 4648],
        "critical": False,
        "description": "Discovery: Remote System Discovery"
    },
    "T1082": {
        "name": "System Information Discovery",
        "tactic": "Discovery",
        "event_ids": [4688],
        "critical": False,
        "description": "Discovery: System Information Discovery"
    },
    "T1033": {
        "name": "System Owner/User Discovery",
        "tactic": "Discovery",
        "event_ids": [4688],
        "critical": False,
        "description": "Discovery: System Owner/User Discovery"
    },
    "T1124": {
        "name": "System Time Discovery",
        "tactic": "Discovery",
        "event_ids": [4688],
        "critical": False,
        "description": "Discovery: System Time Discovery"
    },
    "T1021.001": {
        "name": "Remote Services: Remote Desktop Protocol",
        "tactic": "Lateral Movement",
        "event_ids": [4624, 4778, 4779],
        "critical": True,
        "description": "Lateral Movement: Remote Services: Remote Desktop Protocol"
    },
    "T1021.002": {
        "name": "Remote Services: SMB/Windows Admin Shares",
        "tactic": "Lateral Movement",
        "event_ids": [4624, 4648, 5140, 5145],
        "critical": True,
        "description": "Lateral Movement: Remote Services: SMB/Windows Admin Shares"
    },
    "T1021.003": {
        "name": "Remote Services: Distributed Component Object Model",
        "tactic": "Lateral Movement",
        "event_ids": [4624],
        "critical": False,
        "description": "Lateral Movement: Remote Services: Distributed Component Object Model"
    },
    "T1021.006": {
        "name": "Remote Services: Windows Remote Management",
        "tactic": "Lateral Movement",
        "event_ids": [4624, 4648],
        "critical": True,
        "description": "Lateral Movement: Remote Services: Windows Remote Management"
    },
    "T1047": {
        "name": "Windows Management Instrumentation",
        "tactic": "Lateral Movement",
        "event_ids": [4624, 4648, 4688],
        "critical": True,
        "description": "Lateral Movement: Windows Management Instrumentation"
    },
    "T1091": {
        "name": "Replication Through Removable Media",
        "tactic": "Lateral Movement",
        "event_ids": [4663],
        "critical": False,
        "description": "Lateral Movement: Replication Through Removable Media"
    },
    "T1210": {
        "name": "Exploitation of Remote Services",
        "tactic": "Lateral Movement",
        "event_ids": [4624, 4625, 5156],
        "critical": True,
        "description": "Lateral Movement: Exploitation of Remote Services"
    },
    "T1080": {
        "name": "Taint Shared Content",
        "tactic": "Lateral Movement",
        "event_ids": [5145, 5140],
        "critical": False,
        "description": "Lateral Movement: Taint Shared Content"
    },
    "T1059.001": {
        "name": "Command and Scripting Interpreter: PowerShell",
        "tactic": "Execution",
        "event_ids": [4688, 4103, 4104],
        "critical": True,
        "description": "Execution: Command and Scripting Interpreter: PowerShell"
    },
    "T1059.003": {
        "name": "Command and Scripting Interpreter: Windows Command Shell",
        "tactic": "Execution",
        "event_ids": [4688],
        "critical": True,
        "description": "Execution: Command and Scripting Interpreter: Windows Command Shell"
    },
    "T1106": {
        "name": "Native API",
        "tactic": "Execution",
        "event_ids": [4688],
        "critical": False,
        "description": "Execution: Native API"
    },
    "T1569.002": {
        "name": "System Services: Service Execution",
        "tactic": "Execution",
        "event_ids": [4697, 7045],
        "critical": False,
        "description": "Execution: System Services: Service Execution"
    },
    "T1204.002": {
        "name": "User Execution: Malicious File",
        "tactic": "Execution",
        "event_ids": [4688],
        "critical": False,
        "description": "Execution: User Execution: Malicious File"
    },
    "T1559.001": {
        "name": "Inter-Process Communication: Component Object Model",
        "tactic": "Execution",
        "event_ids": [4688],
        "critical": False,
        "description": "Execution: Inter-Process Communication: Component Object Model"
    },
    "T1203": {
        "name": "Exploitation for Client Execution",
        "tactic": "Execution",
        "event_ids": [4688],
        "critical": False,
        "description": "Execution: Exploitation for Client Execution"
    },
    "T1129": {
        "name": "Shared Modules",
        "tactic": "Execution",
        "event_ids": [4688],
        "critical": False,
        "description": "Execution: Shared Modules"
    },
    "T1005": {
        "name": "Data from Local System",
        "tactic": "Collection",
        "event_ids": [4663],
        "critical": False,
        "description": "Collection: Data from Local System"
    },
    "T1039": {
        "name": "Data from Network Shared Drive",
        "tactic": "Collection",
        "event_ids": [5140, 5145],
        "critical": False,
        "description": "Collection: Data from Network Shared Drive"
    },
    "T1025": {
        "name": "Data from Removable Media",
        "tactic": "Collection",
        "event_ids": [4663],
        "critical": False,
        "description": "Collection: Data from Removable Media"
    },
    "T1074.001": {
        "name": "Data Staged: Local Data Staging",
        "tactic": "Collection",
        "event_ids": [4663],
        "critical": False,
        "description": "Collection: Data Staged: Local Data Staging"
    },
    "T1114.001": {
        "name": "Email Collection: Local Email Collection",
        "tactic": "Collection",
        "event_ids": [4663],
        "critical": False,
        "description": "Collection: Email Collection: Local Email Collection"
    },
    "T1071.001": {
        "name": "Application Layer Protocol: Web Protocols",
        "tactic": "Command and Control",
        "event_ids": [5156],
        "critical": False,
        "description": "Command and Control: Application Layer Protocol: Web Protocols"
    },
    "T1071.004": {
        "name": "Application Layer Protocol: DNS",
        "tactic": "Command and Control",
        "event_ids": [5156],
        "critical": False,
        "description": "Command and Control: Application Layer Protocol: DNS"
    },
    "T1090": {
        "name": "Proxy",
        "tactic": "Command and Control",
        "event_ids": [5156],
        "critical": False,
        "description": "Command and Control: Proxy"
    },
    "T1219": {
        "name": "Remote Access Software",
        "tactic": "Command and Control",
        "event_ids": [4688],
        "critical": False,
        "description": "Command and Control: Remote Access Software"
    },
    "T1041": {
        "name": "Exfiltration Over C2 Channel",
        "tactic": "Exfiltration",
        "event_ids": [5156],
        "critical": False,
        "description": "Exfiltration: Exfiltration Over C2 Channel"
    },
    "T1048": {
        "name": "Exfiltration Over Alternative Protocol",
        "tactic": "Exfiltration",
        "event_ids": [5156],
        "critical": False,
        "description": "Exfiltration: Exfiltration Over Alternative Protocol"
    },
    "T1567.002": {
        "name": "Exfiltration Over Web Service: Exfiltration to Cloud Storage",
        "tactic": "Exfiltration",
        "event_ids": [5156],
        "critical": False,
        "description": "Exfiltration: Exfiltration Over Web Service: Exfiltration to Cloud Storage"
    },
    "T1486": {
        "name": "Data Encrypted for Impact (Ransomware)",
        "tactic": "Impact",
        "event_ids": [4663, 5145],
        "critical": True,
        "description": "Impact: Data Encrypted for Impact (Ransomware)"
    },
    "T1489": {
        "name": "Service Stop",
        "tactic": "Impact",
        "event_ids": [7040, 4697],
        "critical": True,
        "description": "Impact: Service Stop"
    },
    "T1490": {
        "name": "Inhibit System Recovery",
        "tactic": "Impact",
        "event_ids": [4688],
        "critical": True,
        "description": "Impact: Inhibit System Recovery"
    },
    "T1491": {
        "name": "Defacement",
        "tactic": "Impact",
        "event_ids": [4663],
        "critical": False,
        "description": "Impact: Defacement"
    },
    "T1561.001": {
        "name": "Disk Wipe: Disk Content Wipe",
        "tactic": "Impact",
        "event_ids": [4688, 4663],
        "critical": True,
        "description": "Impact: Disk Wipe: Disk Content Wipe"
    },
    "T1078": {
        "name": "Valid Accounts",
        "tactic": "Initial Access",
        "event_ids": [4624, 4625],
        "critical": True,
        "description": "Initial Access: Valid Accounts"
    },
    "T1190": {
        "name": "Exploit Public-Facing Application",
        "tactic": "Initial Access",
        "event_ids": [4624, 5156],
        "critical": True,
        "description": "Initial Access: Exploit Public-Facing Application"
    },
    "T1133": {
        "name": "External Remote Services",
        "tactic": "Initial Access",
        "event_ids": [4624, 4778],
        "critical": False,
        "description": "Initial Access: External Remote Services"
    },

}
