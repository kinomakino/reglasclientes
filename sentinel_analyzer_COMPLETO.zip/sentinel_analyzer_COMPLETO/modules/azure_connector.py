"""
Módulo para conectar con Azure Sentinel y extraer Event IDs
Soporta múltiples métodos de autenticación
"""
import requests
import subprocess
import os
from datetime import datetime, timedelta
from typing import List, Set, Dict, Optional
import json


class AzureSentinelConnector:
    """Conecta con Azure Sentinel via API REST con múltiples métodos de autenticación"""
    
    def __init__(self, workspace_id: str, subscription_id: str, resource_group: str,
                 auth_method: str = 'app', **auth_kwargs):
        """
        Args:
            workspace_id: ID del workspace de Log Analytics
            subscription_id: ID de la suscripción de Azure
            resource_group: Nombre del grupo de recursos
            auth_method: Método de autenticación:
                - 'app': Service Principal (App Registration) [DEFAULT]
                - 'cli': Azure CLI (usa tu login de `az login`)
                - 'msi': Managed Service Identity (para VMs en Azure)
                - 'browser': Interactive Browser (abre navegador para login)
            **auth_kwargs: Credenciales según el método:
                - app: tenant_id, client_id, client_secret
                - cli: (no requiere parámetros adicionales)
                - msi: (no requiere parámetros adicionales)
                - browser: tenant_id, client_id
        """
        self.workspace_id = workspace_id
        self.subscription_id = subscription_id
        self.resource_group = resource_group
        self.auth_method = auth_method
        self.auth_kwargs = auth_kwargs
        self.access_token = None
        
    def authenticate(self) -> bool:
        """Obtiene token de acceso según el método configurado"""
        try:
            if self.auth_method == 'app':
                return self._authenticate_app()
            elif self.auth_method == 'cli':
                return self._authenticate_cli()
            elif self.auth_method == 'msi':
                return self._authenticate_msi()
            elif self.auth_method == 'browser':
                return self._authenticate_browser()
            else:
                print(f"✗ Método de autenticación '{self.auth_method}' no soportado")
                return False
        except Exception as e:
            print(f"✗ Error en autenticación: {e}")
            return False
    
    def _authenticate_app(self) -> bool:
        """Autenticación con Service Principal (App Registration)"""
        tenant_id = self.auth_kwargs.get('tenant_id')
        client_id = self.auth_kwargs.get('client_id')
        client_secret = self.auth_kwargs.get('client_secret')
        
        if not all([tenant_id, client_id, client_secret]):
            print("✗ Faltan credenciales: tenant_id, client_id, client_secret")
            return False
        
        url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
        
        data = {
            'grant_type': 'client_credentials',
            'client_id': client_id,
            'client_secret': client_secret,
            'scope': 'https://management.azure.com/.default'
        }
        
        response = requests.post(url, data=data)
        response.raise_for_status()
        self.access_token = response.json()['access_token']
        print("✓ Autenticación exitosa con Service Principal")
        return True
    
    def _authenticate_cli(self) -> bool:
        """Autenticación usando Azure CLI (usa tu sesión de `az login`)"""
        try:
            # Verificar que Azure CLI está instalado
            result = subprocess.run(['az', '--version'], 
                                  capture_output=True, text=True, timeout=5)
            if result.returncode != 0:
                print("✗ Azure CLI no está instalado")
                print("  Instala con: https://aka.ms/install-azure-cli")
                return False
            
            # Obtener token usando Azure CLI
            cmd = [
                'az', 'account', 'get-access-token',
                '--resource', 'https://management.azure.com',
                '--query', 'accessToken',
                '--output', 'tsv'
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            
            if result.returncode != 0:
                print("✗ Error obteniendo token de Azure CLI")
                print("  ¿Has ejecutado 'az login'?")
                print(f"  Error: {result.stderr}")
                return False
            
            self.access_token = result.stdout.strip()
            
            if not self.access_token:
                print("✗ No se pudo obtener token de Azure CLI")
                print("  Ejecuta: az login")
                return False
            
            print("✓ Autenticación exitosa usando Azure CLI")
            return True
            
        except FileNotFoundError:
            print("✗ Azure CLI no encontrado")
            print("  Instala desde: https://aka.ms/install-azure-cli")
            return False
        except subprocess.TimeoutExpired:
            print("✗ Timeout esperando respuesta de Azure CLI")
            return False
    
    def _authenticate_msi(self) -> bool:
        """Autenticación con Managed Service Identity (para VMs en Azure)"""
        # MSI endpoint en Azure VMs
        msi_endpoint = "http://169.254.169.254/metadata/identity/oauth2/token"
        
        params = {
            'api-version': '2018-02-01',
            'resource': 'https://management.azure.com/'
        }
        
        headers = {'Metadata': 'true'}
        
        response = requests.get(msi_endpoint, params=params, headers=headers, timeout=5)
        response.raise_for_status()
        
        self.access_token = response.json()['access_token']
        print("✓ Autenticación exitosa con Managed Identity")
        return True
    
    def _authenticate_browser(self) -> bool:
        """Autenticación interactiva con navegador (Device Code Flow)"""
        tenant_id = self.auth_kwargs.get('tenant_id')
        client_id = self.auth_kwargs.get('client_id', 
                                         '04b07795-8ddb-461a-bbee-02f9e1bf7b46')  # Azure CLI client ID público
        
        if not tenant_id:
            print("✗ Falta tenant_id para autenticación interactiva")
            return False
        
        # Iniciar device code flow
        device_code_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/devicecode"
        
        # Usar solo el scope de Log Analytics (funciona para queries)
        data = {
            'client_id': client_id,
            'scope': 'https://api.loganalytics.io/.default offline_access'
        }
        
        response = requests.post(device_code_url, data=data)
        
        if response.status_code != 200:
            print(f"✗ Error obteniendo device code: {response.status_code}")
            print(f"   Response: {response.text[:300]}")
            return False
            
        response.raise_for_status()
        device_code_data = response.json()
        
        # Mostrar instrucciones al usuario
        print("\n" + "="*70)
        print("🔐 AUTENTICACIÓN INTERACTIVA REQUERIDA")
        print("="*70)
        print(f"\n{device_code_data['message']}\n")
        print(f"Código: {device_code_data['user_code']}")
        print(f"URL: {device_code_data['verification_uri']}")
        print("\nEsperando autenticación...")
        print("="*70 + "\n")
        
        # Polling para verificar autenticación
        token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
        
        poll_data = {
            'grant_type': 'urn:ietf:params:oauth:grant-type:device_code',
            'client_id': client_id,
            'device_code': device_code_data['device_code']
        }
        
        interval = device_code_data.get('interval', 5)
        expires_in = device_code_data.get('expires_in', 900)
        
        import time
        elapsed = 0
        
        while elapsed < expires_in:
            time.sleep(interval)
            elapsed += interval
            
            response = requests.post(token_url, data=poll_data)
            
            if response.status_code == 200:
                token_data = response.json()
                self.access_token = token_data['access_token']
                print("✓ Autenticación exitosa con navegador")
                return True
            elif response.status_code == 400:
                error = response.json().get('error')
                if error == 'authorization_pending':
                    # Usuario aún no ha completado la autenticación
                    continue
                elif error == 'expired_token':
                    print("✗ El código expiró. Intenta de nuevo.")
                    return False
                else:
                    print(f"✗ Error: {error}")
                    return False
        
        print("✗ Timeout esperando autenticación")
        return False
    
    def list_available_workspaces(self) -> List[Dict]:
        """
        Lista todos los workspaces de Log Analytics disponibles
        Útil para seleccionar interactivamente
        """
        if not self.access_token:
            raise Exception("No autenticado. Ejecuta authenticate() primero")
        
        url = f"https://management.azure.com/subscriptions/{self.subscription_id}/providers/Microsoft.OperationalInsights/workspaces?api-version=2021-06-01"
        
        headers = {
            'Authorization': f'Bearer {self.access_token}',
            'Content-Type': 'application/json'
        }
        
        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            
            workspaces = []
            for workspace in response.json().get('value', []):
                workspaces.append({
                    'name': workspace['name'],
                    'id': workspace['properties']['customerId'],
                    'resource_group': workspace['id'].split('/')[4],
                    'location': workspace['location']
                })
            
            return workspaces
        except Exception as e:
            print(f"✗ Error listando workspaces: {e}")
            return []
    
    def list_subscriptions(self) -> List[Dict]:
        """
        Lista todas las suscripciones disponibles
        """
        if not self.access_token:
            raise Exception("No autenticado. Ejecuta authenticate() primero")
        
        url = "https://management.azure.com/subscriptions?api-version=2020-01-01"
        
        headers = {
            'Authorization': f'Bearer {self.access_token}',
            'Content-Type': 'application/json'
        }
        
        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            
            subscriptions = []
            for sub in response.json().get('value', []):
                subscriptions.append({
                    'name': sub['displayName'],
                    'id': sub['subscriptionId'],
                    'state': sub['state']
                })
            
            return subscriptions
        except Exception as e:
            print(f"✗ Error listando suscripciones: {e}")
            return []
    
    def query_kql(self, query: str, timespan: str = "P7D") -> Dict:
        """
        Ejecuta una query KQL en Log Analytics
        Usa el Workspace ID directamente (customer ID) en lugar de ARM resource path
        
        Args:
            query: Query KQL a ejecutar
            timespan: Rango temporal (formato ISO 8601, ej: P7D = 7 días)
        """
        if not self.access_token:
            raise Exception("No autenticado. Ejecuta authenticate() primero")
        
        # NUEVA API - usar el workspace ID directamente
        url = f"https://api.loganalytics.io/v1/workspaces/{self.workspace_id}/query"
        
        headers = {
            'Authorization': f'Bearer {self.access_token}',
            'Content-Type': 'application/json'
        }
        
        payload = {
            'query': query,
            'timespan': timespan
        }
        
        try:
            response = requests.post(url, headers=headers, json=payload)
            
            # DEBUG: Mostrar detalles de error
            if response.status_code != 200:
                print(f"✗ Error en query KQL:")
                print(f"   Status Code: {response.status_code}")
                print(f"   URL: {url}")
                print(f"   Response: {response.text[:500]}")
                return {}
            
            return response.json()
            
        except requests.exceptions.RequestException as e:
            print(f"✗ Error de conexión en query KQL: {e}")
            return {}
        except Exception as e:
            print(f"✗ Error inesperado en query KQL: {e}")
            return {}
    
    def get_distinct_event_ids(self, days_back: int = 30) -> Set[int]:
        """
        Obtiene todos los Event IDs distintos de SecurityEvent
        
        Args:
            days_back: Días hacia atrás a analizar
        """
        query = f"""
        SecurityEvent
        | where TimeGenerated > ago({days_back}d)
        | distinct EventID
        | project EventID
        """
        
        print(f"Consultando Event IDs de los últimos {days_back} días...")
        result = self.query_kql(query, f"P{days_back}D")
        
        event_ids = set()
        if 'tables' in result and len(result['tables']) > 0:
            rows = result['tables'][0].get('rows', [])
            event_ids = {int(row[0]) for row in rows if row[0] is not None}
            print(f"✓ Encontrados {len(event_ids)} Event IDs distintos")
        else:
            print(f"⚠️  No se encontraron Event IDs o tabla SecurityEvent vacía")
            if result:
                print(f"   Respuesta de API: {result}")
        
        return event_ids
    
    def get_event_id_statistics(self, days_back: int = 30) -> List[Dict]:
        """
        Obtiene estadísticas de Event IDs (frecuencia, hosts, etc.)
        """
        query = f"""
        SecurityEvent
        | where TimeGenerated > ago({days_back}d)
        | summarize 
            Count = count(),
            UniqueComputers = dcount(Computer),
            FirstSeen = min(TimeGenerated),
            LastSeen = max(TimeGenerated)
            by EventID
        | order by Count desc
        """
        
        print(f"Obteniendo estadísticas de Event IDs...")
        result = self.query_kql(query, f"P{days_back}D")
        
        stats = []
        if 'tables' in result and len(result['tables']) > 0:
            columns = result['tables'][0]['columns']
            rows = result['tables'][0]['rows']
            
            for row in rows:
                stat = {}
                for i, col in enumerate(columns):
                    stat[col['name']] = row[i]
                stats.append(stat)
        
        print(f"✓ Estadísticas obtenidas para {len(stats)} Event IDs")
        return stats


class MockSentinelConnector:
    """Conector simulado para pruebas sin acceso real a Sentinel"""
    
    def __init__(self):
        # Event IDs comunes que típicamente se registran
        self.mock_event_ids = {
            4624, 4625, 4634, 4648, 4672, 4688, 4689, 4697, 4698, 4699,
            4700, 4701, 4702, 4720, 4722, 4723, 4724, 4725, 4726, 4738,
            4740, 4756, 4768, 4769, 4776, 4778, 4779, 4798, 5140, 5145,
            1102, 4104, 4103
        }
    
    def authenticate(self) -> bool:
        print("✓ [MODO DEMO] Usando datos simulados")
        return True
    
    def get_distinct_event_ids(self, days_back: int = 30) -> Set[int]:
        print(f"✓ [MODO DEMO] Simulando {len(self.mock_event_ids)} Event IDs")
        return self.mock_event_ids
    
    def get_event_id_statistics(self, days_back: int = 30) -> List[Dict]:
        stats = []
        for eid in sorted(self.mock_event_ids, reverse=True):
            stats.append({
                'EventID': eid,
                'Count': 1000 + (eid % 500),
                'UniqueComputers': 5 + (eid % 10),
                'FirstSeen': '2024-01-01T00:00:00Z',
                'LastSeen': '2024-12-31T23:59:59Z'
            })
        return stats
