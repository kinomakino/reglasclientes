"""
Mapeo de Event IDs a documentación de Microsoft
Para ayudar a los usuarios a configurar los eventos recomendados
"""

EVENT_ID_DOCUMENTATION = {
    # Audit Logon/Logoff
    4624: {
        "name": "An account was successfully logged on",
        "category": "Logon/Logoff",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4624",
        "policy": "Audit Logon",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Logon/Logoff > Audit Logon"
    },
    4625: {
        "name": "An account failed to log on",
        "category": "Logon/Logoff",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4625",
        "policy": "Audit Logon",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Logon/Logoff > Audit Logon"
    },
    4634: {
        "name": "An account was logged off",
        "category": "Logon/Logoff",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4634",
        "policy": "Audit Logoff",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Logon/Logoff > Audit Logoff"
    },
    4648: {
        "name": "A logon was attempted using explicit credentials",
        "category": "Logon/Logoff",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4648",
        "policy": "Audit Logon",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Logon/Logoff > Audit Logon"
    },
    4778: {
        "name": "A session was reconnected to a Window Station",
        "category": "Logon/Logoff",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4778",
        "policy": "Audit Other Logon/Logoff Events",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Logon/Logoff > Audit Other Logon/Logoff Events"
    },
    4779: {
        "name": "A session was disconnected from a Window Station",
        "category": "Logon/Logoff",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4779",
        "policy": "Audit Other Logon/Logoff Events",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Logon/Logoff > Audit Other Logon/Logoff Events"
    },
    
    # Process Tracking
    4688: {
        "name": "A new process has been created",
        "category": "Detailed Tracking",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4688",
        "policy": "Audit Process Creation",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Detailed Tracking > Audit Process Creation"
    },
    4689: {
        "name": "A process has exited",
        "category": "Detailed Tracking",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4689",
        "policy": "Audit Process Termination",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Detailed Tracking > Audit Process Termination"
    },
    
    # Privilege Use
    4672: {
        "name": "Special privileges assigned to new logon",
        "category": "Privilege Use",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4672",
        "policy": "Audit Sensitive Privilege Use",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Privilege Use > Audit Sensitive Privilege Use"
    },
    4673: {
        "name": "A privileged service was called",
        "category": "Privilege Use",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4673",
        "policy": "Audit Sensitive Privilege Use",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Privilege Use > Audit Sensitive Privilege Use"
    },
    4674: {
        "name": "An operation was attempted on a privileged object",
        "category": "Privilege Use",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4674",
        "policy": "Audit Sensitive Privilege Use",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Privilege Use > Audit Sensitive Privilege Use"
    },
    
    # Account Management
    4720: {
        "name": "A user account was created",
        "category": "Account Management",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4720",
        "policy": "Audit User Account Management",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Account Management > Audit User Account Management"
    },
    4722: {
        "name": "A user account was enabled",
        "category": "Account Management",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4722",
        "policy": "Audit User Account Management",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Account Management > Audit User Account Management"
    },
    4738: {
        "name": "A user account was changed",
        "category": "Account Management",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4738",
        "policy": "Audit User Account Management",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Account Management > Audit User Account Management"
    },
    4740: {
        "name": "A user account was locked out",
        "category": "Account Management",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4740",
        "policy": "Audit User Account Management",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Account Management > Audit User Account Management"
    },
    
    # Scheduled Tasks
    4698: {
        "name": "A scheduled task was created",
        "category": "Object Access",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4698",
        "policy": "Audit Other Object Access Events",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Object Access > Audit Other Object Access Events"
    },
    4699: {
        "name": "A scheduled task was deleted",
        "category": "Object Access",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4699",
        "policy": "Audit Other Object Access Events",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Object Access > Audit Other Object Access Events"
    },
    4700: {
        "name": "A scheduled task was enabled",
        "category": "Object Access",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4700",
        "policy": "Audit Other Object Access Events",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Object Access > Audit Other Object Access Events"
    },
    4701: {
        "name": "A scheduled task was disabled",
        "category": "Object Access",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4701",
        "policy": "Audit Other Object Access Events",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Object Access > Audit Other Object Access Events"
    },
    4702: {
        "name": "A scheduled task was updated",
        "category": "Object Access",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4702",
        "policy": "Audit Other Object Access Events",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Object Access > Audit Other Object Access Events"
    },
    
    # Services
    4697: {
        "name": "A service was installed in the system",
        "category": "System",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4697",
        "policy": "Audit Security System Extension",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > System > Audit Security System Extension"
    },
    7045: {
        "name": "A service was installed in the system (System log)",
        "category": "System",
        "doc_url": "https://learn.microsoft.com/en-us/previous-versions/windows/it-pro/windows-10/security/threat-protection/auditing/event-7045",
        "policy": "Automatically enabled with Windows",
        "how_to_enable": "This event is always generated"
    },
    7040: {
        "name": "The start type of a service was changed",
        "category": "System",
        "doc_url": "https://learn.microsoft.com/en-us/previous-versions/windows/it-pro/windows-10/security/threat-protection/auditing/event-7040",
        "policy": "Automatically enabled with Windows",
        "how_to_enable": "This event is always generated"
    },
    
    # Object Access
    4656: {
        "name": "A handle to an object was requested",
        "category": "Object Access",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4656",
        "policy": "Audit File System / Audit Handle Manipulation",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Object Access > Audit File System (and configure SACL on specific files/folders)"
    },
    4663: {
        "name": "An attempt was made to access an object",
        "category": "Object Access",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4663",
        "policy": "Audit File System",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Object Access > Audit File System (and configure SACL on specific files/folders)"
    },
    4657: {
        "name": "A registry value was modified",
        "category": "Object Access",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4657",
        "policy": "Audit Registry",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Object Access > Audit Registry (and configure SACL on specific registry keys)"
    },
    
    # PowerShell
    4103: {
        "name": "Module Logging",
        "category": "PowerShell",
        "doc_url": "https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_logging_windows",
        "policy": "Turn on Module Logging",
        "how_to_enable": "Computer Configuration > Administrative Templates > Windows Components > Windows PowerShell > Turn on Module Logging"
    },
    4104: {
        "name": "Script Block Logging",
        "category": "PowerShell",
        "doc_url": "https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_logging_windows",
        "policy": "Turn on PowerShell Script Block Logging",
        "how_to_enable": "Computer Configuration > Administrative Templates > Windows Components > Windows PowerShell > Turn on PowerShell Script Block Logging"
    },
    
    # Event Log
    1102: {
        "name": "The audit log was cleared",
        "category": "System",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-1102",
        "policy": "Audit System Integrity",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > System > Audit Security State Change"
    },
    104: {
        "name": "The event log was cleared",
        "category": "System",
        "doc_url": "https://learn.microsoft.com/en-us/previous-versions/windows/it-pro/windows-10/security/threat-protection/auditing/event-104",
        "policy": "Automatically enabled",
        "how_to_enable": "This event is always generated"
    },
    1100: {
        "name": "The event logging service has shut down",
        "category": "System",
        "doc_url": "https://learn.microsoft.com/en-us/previous-versions/windows/it-pro/windows-10/security/threat-protection/auditing/event-1100",
        "policy": "Automatically enabled",
        "how_to_enable": "This event is always generated"
    },
    
    # Kerberos
    4768: {
        "name": "A Kerberos authentication ticket (TGT) was requested",
        "category": "Account Logon",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4768",
        "policy": "Audit Kerberos Authentication Service",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Account Logon > Audit Kerberos Authentication Service"
    },
    4769: {
        "name": "A Kerberos service ticket was requested",
        "category": "Account Logon",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4769",
        "policy": "Audit Kerberos Service Ticket Operations",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Account Logon > Audit Kerberos Service Ticket Operations"
    },
    4771: {
        "name": "Kerberos pre-authentication failed",
        "category": "Account Logon",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4771",
        "policy": "Audit Kerberos Authentication Service",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Account Logon > Audit Kerberos Authentication Service"
    },
    4776: {
        "name": "The computer attempted to validate the credentials for an account",
        "category": "Account Logon",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4776",
        "policy": "Audit Credential Validation",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Account Logon > Audit Credential Validation"
    },
    
    # Network Shares
    5140: {
        "name": "A network share object was accessed",
        "category": "Object Access",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-5140",
        "policy": "Audit File Share",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Object Access > Audit File Share"
    },
    5145: {
        "name": "A network share object was checked to see whether client can be granted desired access",
        "category": "Object Access",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-5145",
        "policy": "Audit Detailed File Share",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Object Access > Audit Detailed File Share"
    },
    
    # Filtering Platform
    5156: {
        "name": "The Windows Filtering Platform has permitted a connection",
        "category": "Object Access",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-5156",
        "policy": "Audit Filtering Platform Connection",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Object Access > Audit Filtering Platform Connection"
    },
    5157: {
        "name": "The Windows Filtering Platform has blocked a connection",
        "category": "Object Access",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-5157",
        "policy": "Audit Filtering Platform Connection",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Object Access > Audit Filtering Platform Connection"
    },
    
    # Group Membership
    4798: {
        "name": "A user's local group membership was enumerated",
        "category": "Account Logon",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4798",
        "policy": "Audit User Account Management",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Account Management > Audit User Account Management"
    },
    4799: {
        "name": "A security-enabled local group membership was enumerated",
        "category": "Account Management",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4799",
        "policy": "Audit Security Group Management",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > Account Management > Audit Security Group Management"
    },
    
    # Directory Service Access
    4662: {
        "name": "An operation was performed on an object",
        "category": "DS Access",
        "doc_url": "https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4662",
        "policy": "Audit Directory Service Access",
        "how_to_enable": "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration > DS Access > Audit Directory Service Access (requires SACL configuration)"
    },
    
    # Sysmon (note: not Windows native, requires Sysmon installation)
    10: {
        "name": "Process accessed (Sysmon)",
        "category": "Sysmon",
        "doc_url": "https://learn.microsoft.com/en-us/sysinternals/downloads/sysmon",
        "policy": "Install and configure Sysmon",
        "how_to_enable": "Download Sysmon from Sysinternals and install with a configuration file that includes ProcessAccess events"
    },
    8: {
        "name": "CreateRemoteThread (Sysmon)",
        "category": "Sysmon",
        "doc_url": "https://learn.microsoft.com/en-us/sysinternals/downloads/sysmon",
        "policy": "Install and configure Sysmon",
        "how_to_enable": "Download Sysmon from Sysinternals and install with a configuration file that includes CreateRemoteThread events"
    },
    13: {
        "name": "RegistryEvent (Value Set) - Sysmon",
        "category": "Sysmon",
        "doc_url": "https://learn.microsoft.com/en-us/sysinternals/downloads/sysmon",
        "policy": "Install and configure Sysmon",
        "how_to_enable": "Download Sysmon from Sysinternals and install with a configuration file that includes Registry events"
    }
}


def get_event_documentation(event_id: int) -> dict:
    """Obtiene la documentación de un Event ID específico"""
    return EVENT_ID_DOCUMENTATION.get(event_id, {
        "name": f"Event ID {event_id}",
        "category": "Unknown",
        "doc_url": f"https://www.google.com/search?q=windows+event+id+{event_id}",
        "policy": "Check Microsoft documentation",
        "how_to_enable": "Refer to Windows Event documentation"
    })
