"""
Generador de dashboard HTML interactivo para visualización de gaps MITRE
"""
from datetime import datetime
from typing import Dict, Set
import json
import sys
from pathlib import Path

# Importar documentación de eventos
sys.path.insert(0, str(Path(__file__).parent))
from event_documentation import get_event_documentation


class DashboardGenerator:
    """Genera dashboard HTML interactivo con análisis de cobertura MITRE"""
    
    def __init__(self):
        self.template = self._get_template()
    
    def generate(self, analysis_data: Dict, output_path: str = "dashboard.html"):
        """
        Genera el dashboard HTML completo
        
        Args:
            analysis_data: Diccionario con todos los datos del análisis
            output_path: Ruta donde guardar el HTML
        """
        # Enriquecer recomendaciones con documentación
        enriched_recommendations = []
        for rec in analysis_data['recommendations']:
            doc = get_event_documentation(rec['event_id'])
            enriched_rec = rec.copy()
            enriched_rec['documentation'] = doc
            enriched_recommendations.append(enriched_rec)
        
        html = self.template.format(
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            total_event_ids=analysis_data['total_event_ids'],
            total_techniques=analysis_data['stats']['total_techniques'],
            detectable_count=analysis_data['stats']['detectable_count'],
            undetectable_count=analysis_data['stats']['undetectable_count'],
            partial_count=analysis_data['stats']['partial_count'],
            coverage_pct=f"{analysis_data['stats']['coverage_percentage']:.1f}",
            undetectable_json=json.dumps(analysis_data['undetectable']),
            partial_json=json.dumps(analysis_data['partial']),
            detectable_json=json.dumps(analysis_data['detectable']),
            recommendations_json=json.dumps(enriched_recommendations),
            event_ids_list=json.dumps(sorted(list(analysis_data['available_event_ids'])))
        )
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)
        
        print(f"✓ Dashboard generado: {output_path}")
        return output_path
    
    def _get_template(self) -> str:
        """Retorna el template HTML completo con CSS y JavaScript"""
        return """<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Azure Sentinel - Análisis de Cobertura MITRE ATT&CK</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #0a0a0a;
            min-height: 100vh;
            padding: 20px;
        }}
        
        .container {{
            max-width: 1600px;
            margin: 0 auto;
            background: #1a1a1a;
            border: 3px solid #ffd700;
            border-radius: 20px;
            box-shadow: 0 0 40px rgba(255, 215, 0, 0.3);
            overflow: hidden;
        }}
        
        header {{
            background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
            border-bottom: 3px solid #ffd700;
            color: #ffd700;
            padding: 40px;
            text-align: center;
        }}
        
        header h1 {{
            font-size: 2.5em;
            margin-bottom: 10px;
        }}
        
        header p {{
            opacity: 0.9;
            font-size: 1.1em;
        }}
        
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            padding: 40px;
            background: #0a0a0a;
        }}
        
        .stat-card {{
            background: #1a1a1a;
            border: 2px solid #ffd700;
            padding: 30px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 0 20px rgba(255, 215, 0, 0.2);
            transition: all 0.3s ease;
        }}
        
        .stat-card:hover {{
            transform: translateY(-5px);
            box-shadow: 0 0 30px rgba(255, 215, 0, 0.4);
            border-color: #ffed4e;
        }}
        
        .stat-card .number {{
            font-size: 3em;
            font-weight: bold;
            margin: 10px 0;
        }}
        
        .stat-card .label {{
            color: #999;
            font-size: 0.9em;
            text-transform: uppercase;
            letter-spacing: 1px;
        }}
        
        .stat-card.green .number {{ color: #28a745; }}
        .stat-card.red .number {{ color: #dc3545; }}
        .stat-card.orange .number {{ color: #fd7e14; }}
        .stat-card.blue .number {{ color: #007bff; }}
        
        .content {{
            padding: 40px;
            background: #1a1a1a;
        }}
        
        .section {{
            margin-bottom: 50px;
        }}
        
        .section h2 {{
            color: #ffd700;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 3px solid #ffd700;
        }}
        
        .tabs {{
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            border-bottom: 2px solid #e0e0e0;
        }}
        
        .tab {{
            padding: 12px 24px;
            background: #f8f9fa;
            border: none;
            cursor: pointer;
            font-size: 1em;
            transition: all 0.3s ease;
            border-radius: 8px 8px 0 0;
        }}
        
        .tab.active {{
            background: #667eea;
            color: white;
            font-weight: bold;
        }}
        
        .tab-content {{
            display: none;
        }}
        
        .tab-content.active {{
            display: block;
        }}
        
        .technique-grid {{
            display: grid;
            gap: 15px;
            margin-top: 20px;
        }}
        
        .technique-card {{
            background: #f8f9fa;
            border-left: 5px solid;
            padding: 20px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }}
        
        .technique-card:hover {{
            transform: translateX(5px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }}
        
        .technique-card.critical {{
            border-left-color: #dc3545;
            background: #fff5f5;
        }}
        
        .technique-card.non-critical {{
            border-left-color: #ffc107;
            background: #fffbf0;
        }}
        
        .technique-card.detectable {{
            border-left-color: #28a745;
            background: #0d1f0d;
            border-color: #28a745;
        }}
        
        .technique-header {{
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 10px;
        }}
        
        .technique-id {{
            font-weight: bold;
            color: #ffd700;
            font-size: 1em;
        }}
        
        .technique-id a {{
            color: #ffd700;
            text-decoration: none;
            border-bottom: 2px solid transparent;
            transition: all 0.3s ease;
        }}
        
        .technique-id a:hover {{
            color: #ffed4e;
            border-bottom: 2px solid #ffed4e;
        }}
        
        .technique-name {{
            color: #e0e0e0;
            margin-bottom: 6px;
            font-size: 0.95em;
            line-height: 1.3;
        }}
        
        .technique-tactic {{
            display: inline-block;
            padding: 4px 12px;
            background: #667eea;
            color: white;
            border-radius: 20px;
            font-size: 0.85em;
            margin-right: 10px;
        }}
        
        .badge {{
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: bold;
        }}
        
        .badge.critical {{
            background: #dc3545;
            color: white;
        }}
        
        .badge.partial {{
            background: #ffc107;
            color: #333;
        }}
        
        .badge.complete {{
            background: #28a745;
            color: white;
        }}
        
        .event-ids {{
            margin-top: 10px;
            padding-top: 10px;
            border-top: 1px solid #ddd;
        }}
        
        .event-ids-title {{
            font-weight: bold;
            color: #666;
            font-size: 0.9em;
            margin-bottom: 5px;
        }}
        
        .event-id-tag {{
            display: inline-block;
            padding: 3px 8px;
            background: #e9ecef;
            border-radius: 4px;
            margin: 2px;
            font-size: 0.85em;
            font-family: monospace;
        }}
        
        .event-id-tag.missing {{
            background: #fff5f5;
            border: 1px solid #dc3545;
            color: #dc3545;
        }}
        
        .event-id-tag.available {{
            background: #f0fff4;
            border: 1px solid #28a745;
            color: #28a745;
        }}
        
        .recommendation-card {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 15px;
            cursor: pointer;
            transition: transform 0.3s ease;
        }}
        
        .recommendation-card:hover {{
            transform: scale(1.02);
        }}
        
        .recommendation-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }}
        
        .recommendation-eventid {{
            font-size: 2em;
            font-weight: bold;
        }}
        
        .recommendation-impact {{
            text-align: right;
        }}
        
        .impact-number {{
            font-size: 2.5em;
            font-weight: bold;
        }}
        
        .impact-label {{
            font-size: 0.9em;
            opacity: 0.9;
        }}
        
        .technique-list {{
            background: rgba(255,255,255,0.1);
            padding: 15px;
            border-radius: 8px;
            margin-top: 10px;
        }}
        
        .technique-list-title {{
            font-weight: bold;
            margin-bottom: 8px;
        }}
        
        .technique-pill {{
            display: inline-block;
            padding: 5px 12px;
            background: rgba(255,255,255,0.9);
            color: #333;
            border-radius: 20px;
            margin: 4px;
            font-size: 0.85em;
        }}
        
        .chart-container {{
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }}
        
        .search-box {{
            width: 100%;
            padding: 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1em;
            margin-bottom: 20px;
            transition: border-color 0.3s ease;
        }}
        
        .search-box:focus {{
            outline: none;
            border-color: #667eea;
        }}
        
        .filter-pills {{
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }}
        
        .filter-pill {{
            padding: 8px 16px;
            background: #f8f9fa;
            border: 2px solid #e0e0e0;
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
        }}
        
        .filter-pill:hover {{
            background: #e9ecef;
        }}
        
        .filter-pill.active {{
            background: #667eea;
            color: white;
            border-color: #667eea;
        }}
        
        @media (max-width: 768px) {{
            .stats-grid {{
                grid-template-columns: 1fr;
            }}
            
            header h1 {{
                font-size: 1.8em;
            }}
            
            .tabs {{
                flex-direction: column;
            }}
        }}
        
        .test-attack-btn {{
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.8em;
            font-weight: bold;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }}
        
        .test-attack-btn:hover {{
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(245, 87, 108, 0.4);
        }}
        
        .modal {{
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.7);
        }}
        
        .modal-content {{
            background-color: #1e1e1e;
            color: #d4d4d4;
            margin: 5% auto;
            padding: 0;
            border-radius: 12px;
            width: 80%;
            max-width: 800px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.5);
        }}
        
        .modal-header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 12px 12px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        
        .modal-header h2 {{
            margin: 0;
            font-size: 1.5em;
        }}
        
        .close {{
            color: white;
            font-size: 32px;
            font-weight: bold;
            cursor: pointer;
            line-height: 1;
        }}
        
        .close:hover {{
            transform: scale(1.2);
        }}
        
        .modal-body {{
            padding: 20px;
        }}
        
        .command-box {{
            background: #2d2d2d;
            border: 1px solid #3e3e3e;
            border-radius: 6px;
            padding: 15px;
            font-family: 'Consolas', monospace;
            font-size: 0.9em;
            color: #ce9178;
            white-space: pre-wrap;
            position: relative;
            margin: 10px 0;
        }}
        
        .copy-btn {{
            position: absolute;
            top: 10px;
            right: 10px;
            background: #667eea;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.85em;
        }}
        
        .copy-btn:hover {{
            background: #764ba2;
        }}
        
        .warning-box {{
            background: #3a2a1a;
            border-left: 4px solid #ff6b35;
            padding: 15px;
            margin: 15px 0;
            border-radius: 4px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🛡️ Azure Sentinel - Análisis MITRE ATT&CK</h1>
            <p>Análisis de cobertura de detección basado en Event IDs de Windows</p>
            <p style="font-size: 0.9em; margin-top: 10px;">Generado: {timestamp}</p>
        </header>
        
        <div class="stats-grid">
            <div class="stat-card blue">
                <div class="label">Event IDs Disponibles</div>
                <div class="number">{total_event_ids}</div>
            </div>
            <div class="stat-card green">
                <div class="label">Técnicas Detectables</div>
                <div class="number">{detectable_count}</div>
            </div>
            <div class="stat-card red">
                <div class="label">Gaps Críticos</div>
                <div class="number">{undetectable_count}</div>
            </div>
            <div class="stat-card orange">
                <div class="label">Cobertura Parcial</div>
                <div class="number">{partial_count}</div>
            </div>
        </div>
        
        <div class="content">
            <!-- Event IDs y Gráfico en la misma fila -->
            <div class="section">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                    <div>
                        <h2>📋 Event IDs Registrados</h2>
                        <div id="eventIdsList" style="padding: 20px; background: #0a0a0a; border: 2px solid #ffd700; border-radius: 8px; min-height: 300px;"></div>
                    </div>
                    <div>
                        <h2>📊 Resumen de Cobertura</h2>
                        <div class="chart-container" style="background: #0a0a0a; border: 2px solid #ffd700; border-radius: 8px; padding: 20px;">
                            <canvas id="coverageChart" width="400" height="200"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Recomendaciones -->
            <div class="section">
                <h2>💡 Recomendaciones Prioritarias</h2>
                <p style="margin-bottom: 20px; color: #666;">
                    Event IDs que maximizarían tu cobertura de detección:
                </p>
                <div id="recommendationsContainer" style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px;"></div>
            </div>
            
            <!-- Técnicas -->
            <div class="section">
                <h2>🎯 Análisis de Técnicas MITRE</h2>
                
                <input type="text" class="search-box" id="searchBox" placeholder="🔍 Buscar por ID, nombre o táctica...">
                
                <div class="filter-pills">
                    <div class="filter-pill active" data-filter="all">Todas</div>
                    <div class="filter-pill" data-filter="critical">Solo Críticas</div>
                    <div class="filter-pill" data-filter="persistence">Persistence</div>
                    <div class="filter-pill" data-filter="privilege">Privilege Escalation</div>
                    <div class="filter-pill" data-filter="defense">Defense Evasion</div>
                    <div class="filter-pill" data-filter="credential">Credential Access</div>
                    <div class="filter-pill" data-filter="lateral">Lateral Movement</div>
                </div>
                
                <div class="tabs">
                    <button class="tab active" onclick="switchTab('undetectable')">
                        ❌ No Detectables ({undetectable_count})
                    </button>
                    <button class="tab" onclick="switchTab('partial')">
                        ⚠️ Parcialmente Detectables ({partial_count})
                    </button>
                    <button class="tab" onclick="switchTab('detectable')">
                        ✅ Detectables ({detectable_count})
                    </button>
                </div>
                
                <div id="undetectable" class="tab-content active">
                    <div class="technique-grid" id="undetectableGrid"></div>
                </div>
                
                <div id="partial" class="tab-content">
                    <div class="technique-grid" id="partialGrid"></div>
                </div>
                
                <div id="detectable" class="tab-content">
                    <div class="technique-grid" id="detectableGrid"></div>
                </div>
            </div>
            

        </div>
    </div>
    
    <script>
        // Datos del análisis
        const undetectableData = {undetectable_json};
        const partialData = {partial_json};
        const detectableData = {detectable_json};
        const recommendations = {recommendations_json};
        const availableEventIds = {event_ids_list};
        
        // Renderizar recomendaciones
        function renderRecommendations() {{
            const container = document.getElementById('recommendationsContainer');
            recommendations.forEach((rec, index) => {{
                const card = document.createElement('div');
                card.className = 'recommendation-card';
                
                const doc = rec.documentation || {{}};
                const docLink = doc.doc_url ? 
                    `<a href="${{doc.doc_url}}" target="_blank" style="color: white; text-decoration: underline;">📖 Cómo activar este evento</a>` : 
                    '';
                
                card.innerHTML = `
                    <div class="recommendation-header">
                        <div>
                            <div class="recommendation-eventid">Event ID ${{rec.event_id}}</div>
                            ${{doc.name ? `<div style="font-size: 0.9em; opacity: 0.9; margin-top: 5px;">${{doc.name}}</div>` : ''}}
                        </div>
                        <div class="recommendation-impact">
                            <div class="impact-number">${{rec.critical_impact_score}}</div>
                            <div class="impact-label">Técnicas críticas</div>
                        </div>
                    </div>
                    ${{docLink ? `<div style="margin: 10px 0;">${{docLink}}</div>` : ''}}
                    ${{doc.policy ? `<div style="font-size: 0.85em; opacity: 0.9; margin: 5px 0;">📋 Política: ${{doc.policy}}</div>` : ''}}
                    <div class="technique-list">
                        <div class="technique-list-title">
                            Mejoraría detección de ${{rec.impact_score}} técnicas:
                        </div>
                        ${{rec.techniques_improved.slice(0, 5).map(t => 
                            `<span class="technique-pill">${{t}}</span>`
                        ).join('')}}
                        ${{rec.techniques_improved.length > 5 ? 
                            `<span class="technique-pill">+${{rec.techniques_improved.length - 5}} más</span>` : ''
                        }}
                    </div>
                `;
                container.appendChild(card);
            }});
        }}
        
        // Renderizar técnicas
        function renderTechniques(data, containerId, type) {{
            const container = document.getElementById(containerId);
            container.innerHTML = '';
            
            Object.entries(data).forEach(([techId, tech]) => {{
                const card = document.createElement('div');
                card.className = `technique-card ${{tech.critical ? 'critical' : 'non-critical'}} ${{type}}`;
                card.dataset.tactic = tech.tactic.toLowerCase();
                card.dataset.critical = tech.critical;
                card.dataset.name = tech.name.toLowerCase();
                card.dataset.id = techId.toLowerCase();
                
                let eventIdsHtml = '';
                if (type === 'undetectable') {{
                    eventIdsHtml = `
                        <div class="event-ids">
                            <div class="event-ids-title">Event IDs necesarios (ninguno disponible):</div>
                            ${{tech.missing_event_ids.map(id => 
                                `<span class="event-id-tag missing">${{id}}</span>`
                            ).join('')}}
                        </div>
                    `;
                }} else if (type === 'partial') {{
                    eventIdsHtml = `
                        <div class="event-ids">
                            <div class="event-ids-title">
                                ✅ Disponibles: ${{tech.available_event_ids.length}} | 
                                ❌ Faltantes: ${{tech.missing_event_ids.length}}
                            </div>
                            ${{tech.available_event_ids.map(id => 
                                `<span class="event-id-tag available">${{id}}</span>`
                            ).join('')}}
                            ${{tech.missing_event_ids.map(id => 
                                `<span class="event-id-tag missing">${{id}}</span>`
                            ).join('')}}
                        </div>
                    `;
                }} else {{
                    eventIdsHtml = `
                        <div class="event-ids">
                            <div class="event-ids-title">Event IDs disponibles:</div>
                            ${{tech.available_event_ids.map(id => 
                                `<span class="event-id-tag available">${{id}}</span>`
                            ).join('')}}
                        </div>
                    `;
                }}
                
                card.innerHTML = `
                    <div class="technique-header">
                        <div>
                            <div class="technique-id">
                                <a href="https://attack.mitre.org/techniques/${{techId.replace('.', '/')}}/" target="_blank" title="Ver en MITRE ATT&CK">
                                    ${{techId}}
                                </a>
                            </div>
                            <div class="technique-name">${{tech.name}}</div>
                        </div>
                        <div style="display: flex; gap: 8px; align-items: center;">
                            <button class="test-attack-btn" onclick="showAtomic('${{techId}}', '${{tech.name}}')">
                                🔬 Test
                            </button>
                            ${{tech.critical ? '<span class="badge critical">CRÍTICA</span>' : ''}}
                            ${{type === 'partial' ? `<span class="badge partial">${{Math.round(tech.coverage)}}% cobertura</span>` : ''}}
                        </div>
                    </div>
                    <span class="technique-tactic">${{tech.tactic}}</span>
                    <div style="margin-top: 10px; color: #666; font-size: 0.95em;">
                        ${{tech.description}}
                    </div>
                    ${{eventIdsHtml}}
                `;
                
                container.appendChild(card);
            }});
        }}
        
        // Renderizar lista de Event IDs
        function renderEventIdsList() {{
            const container = document.getElementById('eventIdsList');
            const sorted = availableEventIds.sort((a, b) => a - b);
            container.innerHTML = sorted.map(id => 
                `<span class="event-id-tag available">${{id}}</span>`
            ).join('');
        }}
        
        // Crear gráfico
        function createCoverageChart() {{
            const ctx = document.getElementById('coverageChart').getContext('2d');
            new Chart(ctx, {{
                type: 'doughnut',
                data: {{
                    labels: ['Detectables', 'No Detectables', 'Parciales'],
                    datasets: [{{
                        data: [{detectable_count}, {undetectable_count}, {partial_count}],
                        backgroundColor: ['#28a745', '#dc3545', '#ffc107'],
                        borderWidth: 2,
                        borderColor: '#fff'
                    }}]
                }},
                options: {{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {{
                        legend: {{
                            position: 'bottom',
                            labels: {{
                                font: {{
                                    size: 14
                                }},
                                padding: 20
                            }}
                        }},
                        title: {{
                            display: true,
                            text: 'Cobertura Total: {coverage_pct}%',
                            font: {{
                                size: 18,
                                weight: 'bold'
                            }}
                        }}
                    }}
                }}
            }});
        }}
        
        // Cambiar entre tabs
        function switchTab(tabName) {{
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            
            event.target.classList.add('active');
            document.getElementById(tabName).classList.add('active');
        }}
        
        // Búsqueda
        document.getElementById('searchBox').addEventListener('input', function(e) {{
            const searchTerm = e.target.value.toLowerCase();
            document.querySelectorAll('.technique-card').forEach(card => {{
                const matches = card.dataset.id.includes(searchTerm) ||
                               card.dataset.name.includes(searchTerm) ||
                               card.dataset.tactic.includes(searchTerm);
                card.style.display = matches ? 'block' : 'none';
            }});
        }});
        
        // Filtros
        document.querySelectorAll('.filter-pill').forEach(pill => {{
            pill.addEventListener('click', function() {{
                document.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
                this.classList.add('active');
                
                const filter = this.dataset.filter;
                document.querySelectorAll('.technique-card').forEach(card => {{
                    if (filter === 'all') {{
                        card.style.display = 'block';
                    }} else if (filter === 'critical') {{
                        card.style.display = card.dataset.critical === 'true' ? 'block' : 'none';
                    }} else {{
                        card.style.display = card.dataset.tactic.includes(filter) ? 'block' : 'none';
                    }}
                }});
            }});
        }});
        
        // Inicializar
        document.addEventListener('DOMContentLoaded', function() {{
            renderRecommendations();
            renderTechniques(undetectableData, 'undetectableGrid', 'undetectable');
            renderTechniques(partialData, 'partialGrid', 'partial');
            renderTechniques(detectableData, 'detectableGrid', 'detectable');
            renderEventIdsList();
            createCoverageChart();
        }});
    
        function showAtomic(tid, name) {{
            document.getElementById('modalTitle').textContent = '🔬 ' + tid + ' - ' + name;
            document.getElementById('cmd1').textContent = 'Invoke-AtomicTest ' + tid;
            document.getElementById('atomicModal').style.display = 'block';
        }}
        
        function copyCmd(id) {{
            const text = document.getElementById(id).textContent;
            navigator.clipboard.writeText(text).then(() => {{
                const btn = event.target;
                btn.textContent = '✅ Copiado!';
                setTimeout(() => btn.textContent = '📋 Copiar', 2000);
            }});
        }}
</script>

    <!-- Modal Atomic Red Team -->
    <div id="atomicModal" class="modal" onclick="if(event.target==this) this.style.display='none'">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle">🔬 Test de Ataque</h2>
                <span class="close" onclick="document.getElementById('atomicModal').style.display='none'">&times;</span>
            </div>
            <div class="modal-body">
                <div class="warning-box">
                    <strong>⚠️ ADVERTENCIA:</strong> Solo ejecutar en entornos de laboratorio con permiso explícito.
                </div>
                <h3 style="color: #4ec9b0; margin-top: 20px;">Comando Atomic Red Team:</h3>
                <div class="command-box">
                    <button class="copy-btn" onclick="copyCmd('cmd1')">📋 Copiar</button>
                    <code id="cmd1"></code>
                </div>
                <h3 style="color: #4ec9b0; margin-top: 20px;">Instalación (si no tienes Atomic):</h3>
                <div class="command-box">
                    <button class="copy-btn" onclick="copyCmd('cmd2')">📋 Copiar</button>
                    <code id="cmd2">IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Install-AtomicRedTeam -getAtomics</code>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
"""
