"""
Generador de capa para MITRE ATT&CK Navigator
Crea un mapa visual de cobertura de detección
"""
from datetime import datetime
from typing import Dict, Set
import json


class NavigatorLayerGenerator:
    """Genera archivos JSON compatibles con MITRE ATT&CK Navigator"""
    
    def generate_coverage_layer(self, analysis_data: Dict, output_path: str = "output/coverage_layer.json"):
        """
        Genera una capa del Navigator mostrando cobertura de detección
        
        Colores:
        - Verde (#28a745): Cobertura 100% (detectable)
        - Amarillo (#ffc107): Cobertura parcial (50-99%)
        - Naranja (#fd7e14): Cobertura baja (1-49%)
        - Rojo (#dc3545): Sin cobertura (0%)
        
        Args:
            analysis_data: Diccionario con datos del análisis
            output_path: Ruta donde guardar el JSON
        """
        
        # Combinar todas las técnicas
        all_techniques = {}
        all_techniques.update(analysis_data['detectable'])
        all_techniques.update(analysis_data['partial'])
        all_techniques.update(analysis_data['undetectable'])
        
        # Crear técnicas para el Navigator
        techniques = []
        
        for tech_id, tech_data in all_techniques.items():
            coverage = tech_data.get('coverage', 0)
            
            # Determinar color según cobertura
            if coverage == 100:
                color = "#28a745"  # Verde - Detectable
                score_display = "100%"
            elif coverage >= 50:
                color = "#ffc107"  # Amarillo - Parcial alta
                score_display = f"{int(coverage)}%"
            elif coverage > 0:
                color = "#fd7e14"  # Naranja - Parcial baja
                score_display = f"{int(coverage)}%"
            else:
                color = "#dc3545"  # Rojo - No detectable
                score_display = "0%"
            
            # Crear comentario con detalles
            event_ids_available = tech_data.get('available_event_ids', [])
            event_ids_missing = tech_data.get('missing_event_ids', [])
            
            comment_parts = [
                f"Cobertura: {score_display}",
                f"Táctica: {tech_data['tactic']}"
            ]
            
            if tech_data.get('critical'):
                comment_parts.append("⚠️ CRÍTICA")
            
            if event_ids_available:
                comment_parts.append(f"Event IDs disponibles: {', '.join(map(str, event_ids_available))}")
            
            if event_ids_missing:
                comment_parts.append(f"Event IDs faltantes: {', '.join(map(str, event_ids_missing))}")
            
            comment = " | ".join(comment_parts)
            
            technique = {
                "techniqueID": tech_id,
                "score": coverage,
                "color": color,
                "comment": comment,
                "enabled": True,
                "metadata": [
                    {
                        "name": "Cobertura",
                        "value": score_display
                    },
                    {
                        "name": "Criticidad",
                        "value": "Alta" if tech_data.get('critical') else "Media"
                    }
                ]
            }
            
            techniques.append(technique)
        
        # Crear la capa del Navigator
        layer = {
            "name": "Azure Sentinel - Cobertura de Detección",
            "versions": {
                "attack": "18",
                "navigator": "4.9.4",
                "layer": "4.5"
            },
            "domain": "enterprise-attack",
            "description": f"Mapa de cobertura de detección basado en Event IDs disponibles en Azure Sentinel. Generado: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}. Total Event IDs: {analysis_data['total_event_ids']}. Cobertura: {analysis_data['stats']['coverage_percentage']:.1f}%",
            "filters": {
                "platforms": ["windows"]
            },
            "sorting": 3,
            "layout": {
                "layout": "side",
                "aggregateFunction": "average",
                "showID": True,
                "showName": True,
                "showAggregateScores": False,
                "countUnscored": False
            },
            "hideDisabled": False,
            "techniques": techniques,
            "gradient": {
                "colors": [
                    "#dc3545",  # Rojo (0%)
                    "#fd7e14",  # Naranja (25%)
                    "#ffc107",  # Amarillo (50%)
                    "#28a745"   # Verde (100%)
                ],
                "minValue": 0,
                "maxValue": 100
            },
            "legendItems": [
                {
                    "label": "100% - Detectable (todos los Event IDs)",
                    "color": "#28a745"
                },
                {
                    "label": "50-99% - Cobertura parcial",
                    "color": "#ffc107"
                },
                {
                    "label": "1-49% - Cobertura baja",
                    "color": "#fd7e14"
                },
                {
                    "label": "0% - No detectable (sin Event IDs)",
                    "color": "#dc3545"
                }
            ],
            "metadata": [
                {
                    "name": "Total Técnicas",
                    "value": str(analysis_data['stats']['total_techniques'])
                },
                {
                    "name": "Detectables",
                    "value": str(analysis_data['stats']['detectable_count'])
                },
                {
                    "name": "Parciales",
                    "value": str(analysis_data['stats']['partial_count'])
                },
                {
                    "name": "No Detectables",
                    "value": str(analysis_data['stats']['undetectable_count'])
                },
                {
                    "name": "Cobertura General",
                    "value": f"{analysis_data['stats']['coverage_percentage']:.1f}%"
                },
                {
                    "name": "Total Event IDs",
                    "value": str(analysis_data['total_event_ids'])
                }
            ],
            "showTacticRowBackground": True,
            "tacticRowBackground": "#dddddd",
            "selectTechniquesAcrossTactics": True,
            "selectSubtechniquesWithParent": False
        }
        
        # Guardar archivo
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(layer, f, indent=2, ensure_ascii=False)
        
        print(f"✓ Capa Navigator generada: {output_path}")
        print(f"  📊 {len(techniques)} técnicas mapeadas")
        print(f"  🌐 Carga el archivo en: https://mitre-attack.github.io/attack-navigator/")
        
        return output_path
    
    def generate_critical_only_layer(self, analysis_data: Dict, output_path: str = "output/critical_gaps_layer.json"):
        """
        Genera una capa mostrando SOLO técnicas críticas sin cobertura
        Útil para priorizar esfuerzos
        """
        
        # Filtrar solo técnicas críticas sin cobertura
        critical_gaps = {
            tid: data for tid, data in analysis_data['undetectable'].items()
            if data.get('critical', False)
        }
        
        critical_partial = {
            tid: data for tid, data in analysis_data['partial'].items()
            if data.get('critical', False)
        }
        
        techniques = []
        
        # Técnicas críticas sin cobertura (rojo)
        for tech_id, tech_data in critical_gaps.items():
            techniques.append({
                "techniqueID": tech_id,
                "score": 100,
                "color": "#dc3545",
                "comment": f"🔴 GAP CRÍTICO | Necesita: {', '.join(map(str, tech_data['missing_event_ids']))}",
                "enabled": True
            })
        
        # Técnicas críticas con cobertura parcial (amarillo)
        for tech_id, tech_data in critical_partial.items():
            techniques.append({
                "techniqueID": tech_id,
                "score": tech_data['coverage'],
                "color": "#ffc107",
                "comment": f"⚠️ PARCIAL | Cobertura: {int(tech_data['coverage'])}% | Faltantes: {', '.join(map(str, tech_data['missing_event_ids']))}",
                "enabled": True
            })
        
        layer = {
            "name": "Azure Sentinel - GAPS CRÍTICOS",
            "versions": {
                "attack": "18",
                "navigator": "4.9.4",
                "layer": "4.5"
            },
            "domain": "enterprise-attack",
            "description": f"Técnicas CRÍTICAS con cobertura incompleta o nula. Prioriza estos gaps. Generado: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "filters": {
                "platforms": ["windows"]
            },
            "sorting": 3,
            "layout": {
                "layout": "side",
                "showID": True,
                "showName": True
            },
            "hideDisabled": False,
            "techniques": techniques,
            "legendItems": [
                {
                    "label": "Sin cobertura - Prioridad ALTA",
                    "color": "#dc3545"
                },
                {
                    "label": "Cobertura parcial - Prioridad MEDIA",
                    "color": "#ffc107"
                }
            ],
            "metadata": [
                {
                    "name": "Total Gaps Críticos",
                    "value": str(len(critical_gaps))
                },
                {
                    "name": "Críticas Parciales",
                    "value": str(len(critical_partial))
                }
            ]
        }
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(layer, f, indent=2, ensure_ascii=False)
        
        print(f"✓ Capa de gaps críticos generada: {output_path}")
        print(f"  🔴 {len(critical_gaps)} técnicas críticas sin cobertura")
        print(f"  ⚠️  {len(critical_partial)} técnicas críticas parciales")
        
        return output_path
