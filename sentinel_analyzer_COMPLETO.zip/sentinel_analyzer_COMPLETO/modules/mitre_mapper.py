"""
Mapper de técnicas MITRE ATT&CK a Event IDs de Windows
Expandido a 100+ técnicas usando OSSEM Project data
"""
from typing import Dict, Set, List
try:
    from .mitre_techniques_data import MITRE_TECHNIQUES
except ImportError:
    from mitre_techniques_data import MITRE_TECHNIQUES


class MITREMapper:
    """Mapea Event IDs a técnicas MITRE ATT&CK"""
    
    def __init__(self):
        self.techniques = MITRE_TECHNIQUES
    
    def analyze_coverage(self, available_event_ids: Set[int]) -> Dict:
        """
        Analiza qué técnicas pueden/no pueden detectarse con los Event IDs disponibles
        
        Returns:
            Dict con 'detectable', 'partial', 'undetectable', y 'stats'
        """
        detectable = {}
        partial = {}
        undetectable = {}
        
        for tech_id, tech_data in self.techniques.items():
            required_ids = set(tech_data['event_ids'])
            available_for_tech = required_ids & available_event_ids
            missing_ids = required_ids - available_event_ids
            
            coverage = (len(available_for_tech) / len(required_ids)) * 100 if required_ids else 0
            
            tech_info = {
                'name': tech_data['name'],
                'tactic': tech_data['tactic'],
                'description': tech_data.get('description', ''),
                'critical': tech_data.get('critical', False),
                'required_event_ids': list(required_ids),
                'available_event_ids': list(available_for_tech),
                'missing_event_ids': list(missing_ids),
                'coverage': coverage
            }
            
            if coverage == 100:
                detectable[tech_id] = tech_info
            elif coverage > 0:
                partial[tech_id] = tech_info
            else:
                undetectable[tech_id] = tech_info
        
        # Estadísticas
        total = len(self.techniques)
        stats = {
            'total_techniques': total,
            'detectable_count': len(detectable),
            'partial_count': len(partial),
            'undetectable_count': len(undetectable),
            'coverage_percentage': (len(detectable) / total) * 100 if total > 0 else 0
        }
        
        return {
            'detectable': detectable,
            'partial': partial,
            'undetectable': undetectable,
            'stats': stats
        }
    
    def recommend_event_ids(self, available_event_ids: Set[int], top_n: int = 15) -> List[Dict]:
        """
        Recomienda qué Event IDs activar para mejorar cobertura
        Prioriza por impacto en técnicas críticas
        """
        # Contar cuántas técnicas mejoraría cada Event ID
        event_impact = {}
        
        for tech_id, tech_data in self.techniques.items():
            required_ids = set(tech_data['event_ids'])
            missing_ids = required_ids - available_event_ids
            
            for event_id in missing_ids:
                if event_id not in event_impact:
                    event_impact[event_id] = {
                        'techniques_improved': [],
                        'critical_techniques': []
                    }
                
                event_impact[event_id]['techniques_improved'].append(tech_id)
                
                if tech_data.get('critical', False):
                    event_impact[event_id]['critical_techniques'].append(tech_id)
        
        # Ordenar por impacto (críticas primero, luego total)
        recommendations = []
        for event_id, impact in event_impact.items():
            recommendations.append({
                'event_id': event_id,
                'impact_score': len(impact['techniques_improved']),
                'critical_impact_score': len(impact['critical_techniques']),
                'techniques_improved': impact['techniques_improved']
            })
        
        # Ordenar: primero por críticas, luego por total
        recommendations.sort(
            key=lambda x: (x['critical_impact_score'], x['impact_score']),
            reverse=True
        )
        
        return recommendations[:top_n]
