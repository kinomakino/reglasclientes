#!/usr/bin/env python3
"""
Azure Sentinel TTP Gap Analyzer - VERSIÓN OFFLINE
Analiza qué técnicas MITRE ATT&CK no pueden detectarse por falta de Event IDs
Lee los Event IDs desde un archivo local (no necesita conectarse a Azure)
"""
import sys
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / 'modules'))

from mitre_mapper import MITREMapper
from dashboard_generator import DashboardGenerator
from navigator_generator import NavigatorLayerGenerator


def read_event_ids_from_file(filepath='event_ids.txt'):
    """
    Lee Event IDs desde un archivo
    
    Formatos soportados:
    - Un Event ID por línea: 4624
    - CSV: 4624,4625,4688
    - Salida KQL copiada directamente
    """
    event_ids = set()
    
    if not os.path.exists(filepath):
        print(f"❌ No se encuentra el archivo: {filepath}")
        print()
        print("📝 CÓMO OBTENER TUS EVENT IDs:")
        print()
        print("1. Ve a Azure Portal → Sentinel → Logs")
        print("2. Ejecuta esta query KQL:")
        print()
        print("   SecurityEvent")
        print("   | where TimeGenerated > ago(7d)")
        print("   | distinct EventID")
        print("   | order by EventID asc")
        print()
        print("3. Copia los resultados y pégalos en 'event_ids.txt'")
        print("   (un Event ID por línea)")
        print()
        return None
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Intentar parsear diferentes formatos
        import re
        
        # Buscar todos los números en el archivo
        numbers = re.findall(r'\b\d{1,5}\b', content)
        
        for num in numbers:
            try:
                event_id = int(num)
                # Filtrar números que parecen Event IDs (entre 1 y 65535)
                if 1 <= event_id <= 65535:
                    event_ids.add(event_id)
            except ValueError:
                continue
        
        print(f"✓ Leídos {len(event_ids)} Event IDs desde {filepath}")
        
        return event_ids
        
    except Exception as e:
        print(f"❌ Error leyendo archivo: {e}")
        return None


def main():
    print("=" * 70)
    print("🛡️  AZURE SENTINEL - MITRE ATT&CK GAP ANALYZER (OFFLINE)")
    print("=" * 70)
    print()
    
    # Leer Event IDs desde archivo
    print("PASO 1: Leyendo Event IDs desde archivo...")
    print("-" * 70)
    
    available_event_ids = read_event_ids_from_file('event_ids.txt')
    
    if available_event_ids is None:
        return
    
    if len(available_event_ids) == 0:
        print("❌ No se encontraron Event IDs válidos en el archivo")
        print("💡 Asegúrate de que el archivo contenga números (Event IDs)")
        return
    
    print(f"Event IDs encontrados: {sorted(available_event_ids)}")
    print()
    
    # Analizar con MITRE
    print("PASO 2: Analizando cobertura MITRE ATT&CK...")
    print("-" * 70)
    
    mapper = MITREMapper()
    coverage_analysis = mapper.analyze_coverage(available_event_ids)
    
    stats = coverage_analysis['stats']
    print(f"📊 ESTADÍSTICAS:")
    print(f"   Total técnicas mapeadas: {stats['total_techniques']}")
    print(f"   ✅ Detectables (100%):    {stats['detectable_count']}")
    print(f"   ⚠️  Parciales:             {stats['partial_count']}")
    print(f"   ❌ No detectables (0%):   {stats['undetectable_count']}")
    print(f"   📈 Cobertura general:     {stats['coverage_percentage']:.1f}%")
    print()
    
    # Recomendaciones
    print("PASO 3: Generando recomendaciones...")
    print("-" * 70)
    
    recommendations = mapper.recommend_event_ids(available_event_ids, top_n=15)
    
    print("💡 TOP 10 Event IDs RECOMENDADOS:")
    for i, rec in enumerate(recommendations[:10], 1):
        critical_mark = "🔴" if rec['critical_impact_score'] > 0 else "🟡"
        print(f"{i:2d}. {critical_mark} Event ID {rec['event_id']:4d} → "
              f"{rec['critical_impact_score']} críticas, "
              f"{rec['impact_score']} total")
    print()
    
    # Dashboard
    print("PASO 4: Generando dashboard HTML...")
    print("-" * 70)
    
    dashboard_data = {
        'total_event_ids': len(available_event_ids),
        'available_event_ids': available_event_ids,
        'undetectable': coverage_analysis['undetectable'],
        'partial': coverage_analysis['partial'],
        'detectable': coverage_analysis['detectable'],
        'stats': stats,
        'recommendations': recommendations
    }
    
    generator = DashboardGenerator()
    output_path = 'output/sentinel_mitre_dashboard.html'
    
    os.makedirs('output', exist_ok=True)
    generator.generate(dashboard_data, output_path)
    
    print()
    print("PASO 5: Generando capas para MITRE ATT&CK Navigator...")
    print("-" * 70)
    
    nav_generator = NavigatorLayerGenerator()
    
    # Capa completa de cobertura
    coverage_layer = nav_generator.generate_coverage_layer(
        dashboard_data,
        'output/coverage_layer.json'
    )
    
    # Capa de gaps críticos
    critical_layer = nav_generator.generate_critical_only_layer(
        dashboard_data,
        'output/critical_gaps_layer.json'
    )
    
    print()
    print("=" * 70)
    print("✅ ANÁLISIS COMPLETADO")
    print("=" * 70)
    print(f"📄 Dashboard HTML: {output_path}")
    print(f"🗺️  Capa Navigator (Cobertura): {coverage_layer}")
    print(f"🔴 Capa Navigator (Gaps Críticos): {critical_layer}")
    print()
    print("🌐 CÓMO USAR LAS CAPAS DEL NAVIGATOR:")
    print("   1. Ve a: https://mitre-attack.github.io/attack-navigator/")
    print("   2. Click en '+ Create New Layer' → 'Open Existing Layer'")
    print("   3. Carga: coverage_layer.json (mapa completo de cobertura)")
    print("   4. O carga: critical_gaps_layer.json (solo gaps críticos)")
    print()
    print("📊 Dashboard HTML:")
    print("   Abre sentinel_mitre_dashboard.html en tu navegador")
    print()
    
    # Gaps críticos
    critical_gaps = {
        tid: data for tid, data in coverage_analysis['undetectable'].items()
        if data.get('critical', False)
    }
    
    if critical_gaps:
        print("⚠️  GAPS CRÍTICOS DETECTADOS:")
        print("-" * 70)
        for tid, data in list(critical_gaps.items())[:5]:
            print(f"  {tid}: {data['name']}")
            print(f"  └─ Necesita Event IDs: {data['missing_event_ids']}")
        
        if len(critical_gaps) > 5:
            print(f"  ... y {len(critical_gaps) - 5} técnicas críticas más")
        print()


if __name__ == '__main__':
    main()
